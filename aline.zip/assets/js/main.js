		

		
		$(document).ready(function(){
			$(".controller").owlCarousel({
				loop:true,
				responsiveClass:true,
				stagePadding: 50,
				autoplay:true,
				margin:10,
				autoHeight:true,
    			autoplayTimeout:3000,
    			autoplayHoverPause:true,
			    responsive:{
			        0:{
			            items:1,
			            nav:false,
			        },
			        600:{
			            items:1,
			            nav:false
			        },
			        1000:{
			            items:2,
			            nav:false,
			            loop:true,
			        }
			    }
			});
		});


		if (typeof jQuery == "undefined"){
			alert('Erro has taken place')
		}
		/*$(".navbar-toggler").click( function(){
			//$(".navbar-modile").css("display","block")
			$(".navbar").addClass("navbar-modile")
			$(".navbar-toggler").addClass("navbar-toggler-close")
			$(".navbar-toggler").addClass("navbar-toggler")

		})

		$(".navbar-toggler-close").click(function(){
			$(".navbar").removeClass("navbar-modile")
			$(".navbar-toggler").removeClass("navbar-toggler-close")

		})*/
		let active = true
		$("#navbar-toggler").click(function(){
			
			if(active){
				$(".navbar").addClass("navbar-modile")
				$(".toggle-icon i").removeClass("fa-bars")
				$(".toggle-icon i").addClass("fa-xmark")
				$(".header .click-circle").css("display", "none")
				active = false	
			}else{
				$(".navbar").removeClass("navbar-modile")
				$(".toggle-icon i").removeClass("fa-xmark")
				$(".toggle-icon i").addClass("fa-bars")
				$(".header .click-circle").css("display", "block")
				active = true
			}
			//$(".navbar").addClass("navbar-modile")
		})

		function filterIn(){
			$(".header .container p").show()
			$(".header .container h1").removeClass("sm-txt")
			$(".header .container h1").addClass("lg-txt")

			$(".header .container").removeClass("d-flex justify-content-between")

			$(".header").removeClass("header-top")
			$(".about").fadeOut("slow")
			$(".resume").fadeOut("slow")
			$(".service").fadeOut("fast")
			$(".portfolio").fadeOut("fast")
			$(".contact").fadeOut("fast")
		}

		function filterOut(){
			$(".header").addClass("header-top")
			$(".header .container p").hide()
			$(".header .container h1").addClass("sm-txt")
			$(".header .container h1").removeClass("lg-txt")

			$(".header .container").addClass("d-flex justify-content-between")
			$(".about").fadeOut("fast")
			$(".resume").fadeOut("fast")
			$(".service").fadeOut("fast")
			$(".portfolio").fadeOut("fast")
			$(".contact").fadeOut("fast")

			
		}

		$(".navbar #link").click(function() {
			$(this).addClass("active").siblings().removeClass("active")
		})

		$("#headerlink").click(function(){
			filterIn()
			$(".header").fadeIn("slow")
			$(".navbar").removeClass("navbar-modile")

			$(".toggle-icon i").removeClass("fa-xmark")
			$(".toggle-icon i").addClass("fa-bars")
			$(".header .click-circle").css("display", "block")
			active = true
		})
		
		$("#about").click(function(){
			filterOut()
			$(".about").fadeIn("slow")
			$(".navbar").removeClass("navbar-modile")

			$(".toggle-icon i").removeClass("fa-xmark")
			$(".toggle-icon i").addClass("fa-bars")
			active = true
		})
		$("#resume").click(function(){
			filterOut()
			$(".resume").fadeIn("slow")
			$(".navbar").removeClass("navbar-modile")

			$(".toggle-icon i").removeClass("fa-xmark")
			$(".toggle-icon i").addClass("fa-bars")
			active = true
		})
		$("#service").click(function(){
			filterOut()
			$(".service").fadeIn("slow")
			$(".navbar").removeClass("navbar-modile")

			$(".toggle-icon i").removeClass("fa-xmark")
			$(".toggle-icon i").addClass("fa-bars")
			active = true
		})
		$("#portfolio").click(function(){
			filterOut()
			$(".portfolio").fadeIn("slow")
			$(".navbar").removeClass("navbar-modile")

			$(".toggle-icon i").removeClass("fa-xmark")
			$(".toggle-icon i").addClass("fa-bars")
			active = true
		})
		$("#contact").click(function(){
			filterOut()
			$(".contact").fadeIn("slow")
			$(".navbar").removeClass("navbar-modile")

			$(".toggle-icon i").removeClass("fa-xmark")
			$(".toggle-icon i").addClass("fa-bars")
			active = true
		})

		$('.portfolio-sec .portfolio-btn-controls button').click(function(){
			$(this).addClass('active').siblings().removeClass('active');

                let filter = $(this).attr('data-filter');

                if(filter == 'port-all'){
                    $('.image').show(500);
                }
                else{
                    $('.image').not('.'+filter).hide(400);
                    $('.image').filter('.'+filter).show(500);
                }
		})